from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('home.urls')),
    path('member/', include('member.urls')),
    path('mypage/', include('mypage.urls')),
    
    path('magazine/', include('magazine.urls')),
    path('store/', include('store.urls')),
    path('board/', include('board.urls')),
    path('restaurants/', include('restaurants.urls')),
]

# 파일업로드시 url구성, urlpatterns에 추가 설정
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
