from django.apps import AppConfig


class MypageConfig(AppConfig):
    name = 'mypage'
