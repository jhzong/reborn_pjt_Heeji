from django.contrib import admin
from member.models import MyUser

# Register your models here.

admin.site.register(MyUser)

