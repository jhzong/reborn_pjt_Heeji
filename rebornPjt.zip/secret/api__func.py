def naver__API():
    client_id= 'C_MasXzr3nCzi13g19wN'
    client_secret= 'mUtwlSX2ES'
    return client_id,client_secret