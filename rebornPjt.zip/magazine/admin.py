from django.contrib import admin
from magazine.models import Magazine, Magazine_code

# Register your models here.

admin.site.register(Magazine)
admin.site.register(Magazine_code)
