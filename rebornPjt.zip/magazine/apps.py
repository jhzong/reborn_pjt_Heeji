from django.apps import AppConfig


class MagazineConfig(AppConfig):
    name = 'magazine'
